# 👁️ TruthLens — User Guide

### *Can you trust what you see online? We built a tool to help answer that.*

---

## Why We Built This

Every day, millions of AI-generated images are shared across social media, news websites, messaging apps, and online marketplaces. Some are harmless — art, entertainment, fun filters. But many are not.

AI-generated images are being used to:

- **Spread misinformation** — fake news photos that look completely real
- **Create fake identities** — profile pictures of people who don't exist
- **Commit fraud** — fake product photos, fake ID documents, fake evidence
- **Manipulate public opinion** — fabricated images of political figures or events
- **Scam people** — fake listings, fake celebrity endorsements, fake testimonials

The problem is growing fast. Today's AI image generators (Midjourney, DALL-E, Stable Diffusion) are so advanced that the human eye simply cannot keep up. An image that took an expert 10 minutes to analyze can now be generated in 3 seconds.

**We built TruthLens because everyone deserves to know what's real.**

Not just journalists. Not just fact-checkers. Everyone — you, your parents, your colleagues, anyone who receives an image and needs to decide whether to trust it.

---

## What This Tool Does

TruthLens analyzes an image and tells you, clearly and immediately:

> **"This is AI-generated"** or **"This appears authentic"**

It does this by running a forensic analysis — the same kind of inspection a digital media expert would do, but automated and available to anyone in seconds.

Under the hood, it looks at six forensic signals:

| Signal | What it checks |
|---|---|
| **Noise Pattern** | Real cameras produce natural, irregular sensor noise. AI images have synthetic or injected noise that follows different statistical patterns. |
| **Edge Coherence** | In real photos, edges blur naturally based on focus and depth. AI images often show unnatural sharpness, halo artifacts, or inconsistent edge transitions. |
| **Texture Realism** | Human skin, fabric, wood, grass — all have micro-detail that is hard for AI to replicate perfectly. Over-smooth or repetitively patterned textures are a signal. |
| **Lighting Consistency** | In a real photo, shadows and highlights follow the laws of physics. AI images frequently have lighting that doesn't quite add up — a face lit from the left with a shadow falling the wrong way. |
| **Frequency Domain** | Every camera sensor leaves a unique frequency fingerprint in the image data. AI generation tools leave a different kind of fingerprint that can be detected mathematically. |
| **Structural Symmetry** | Real human faces and natural scenes have subtle, organic asymmetry. AI models tend to produce near-perfect symmetry that doesn't occur naturally. |

After analyzing these signals, TruthLens gives you a verdict and a confidence score, then offers a plain-English explanation of exactly what it found.

---

## Who Should Use This

**You should use TruthLens if you ever:**

- Receive an image in a message and wonder if it's real
- See a photo in a news article that seems too dramatic or too perfect
- Are verifying a profile picture on a dating app or social platform
- Are a journalist, researcher, or fact-checker verifying media
- Run a marketplace or platform and need to screen user-uploaded images
- Are a teacher, parent, or student learning about AI and media literacy
- Just want to know — out of curiosity — whether something is real

**You do not need any technical knowledge to use it.** No code, no accounts, no settings.

---

## How to Use TruthLens

Using TruthLens takes about 30 seconds. Here is exactly what to do:

### Step 1 — Get the image

Save the image you want to check to your device. You can:
- Right-click any image online and choose "Save image as"
- Take a screenshot
- Download it from a message or social media post

### Step 2 — Upload it

Open TruthLens and either:
- **Drag and drop** the image file onto the upload area, or
- Click **"Browse Files"** and select the image from your device

Supported formats: JPG, PNG, WEBP, GIF. Maximum size: 10MB.

### Step 3 — Run the analysis

Click the **"Run Forensic Analysis"** button. You will see a scanning animation as TruthLens works through each forensic check — this usually takes 5–15 seconds.

### Step 4 — Read the verdict

The result appears as one of three verdicts:

- 🤖 **AI Generated** — The image shows strong signs of being created by an AI model. The confidence score tells you how certain the analysis is (e.g. 91% confident).
- ✅ **Authentic** — The image shows characteristics consistent with a real photograph.
- 🤔 **Uncertain** — The signals are mixed. This can happen with heavily edited real photos, or very high-quality AI images. Treat it as a yellow flag.

### Step 5 — Understand why (optional)

After the verdict, TruthLens will ask: **"Want to know why we think this?"**

Click **"Yes, explain it"** to see the full breakdown:
- Each of the 6 forensic signals with a score and plain-English explanation
- A technical analysis paragraph
- A recommendation for what to do with this finding

---

## Understanding the Confidence Score

The confidence score (shown as a percentage) tells you how certain the analysis is.

| Score | What it means |
|---|---|
| **85–100%** | Very high confidence. Strong, consistent signals support the verdict. |
| **65–84%** | Good confidence. Most signals agree, a few are ambiguous. |
| **45–64%** | Moderate confidence. Treat the result as a strong indicator, not a guarantee. |
| **Below 45%** | Low confidence. The image is genuinely difficult to classify — use other methods too. |

**Important:** No tool is 100% accurate. TruthLens is a powerful aid for detection, not a final legal verdict. Always use your own judgment alongside the result, especially for high-stakes decisions.

---

## What TruthLens Cannot Do

To use this tool responsibly, it helps to know its limits:

- It **cannot** detect every AI image — the most sophisticated AI generators are constantly improving, and some images will fool any detector
- It **cannot** tell you *who* created an image or *which* AI tool was used
- It **cannot** analyze videos (coming soon)
- It **cannot** read text inside an image or identify people
- It is **not** a substitute for expert forensic analysis in legal or official contexts

---

## Frequently Asked Questions

**Is my image stored or shared?**
No. Your image is analyzed in the moment and is not saved, stored, or shared with anyone.

**It said "Authentic" but I'm sure it's AI — why?**
Very high-quality or adversarially processed AI images can defeat detection. If you have other reasons to suspect the image, trust your instincts and investigate further.

**It said "AI Generated" but it's my real photo — why?**
Heavily filtered, edited, or stylized real photos can trigger AI signals. If you know the photo is real, the result may be a false positive. This is rare with unedited photos.

**Can I use this for professional or legal purposes?**
TruthLens is a general-purpose detection aid. For professional forensic investigations, you should consult a certified digital media expert and use multiple verification tools.

**How do I report a wrong result?**
Use the thumbs down button in the interface to send feedback. Every report helps improve the model.

---

## The Bigger Picture

TruthLens is part of a broader effort to build AI tools that make AI itself more trustworthy. As AI-generated content becomes indistinguishable from reality, the tools to verify that reality must become just as powerful.

This project was built using the **OpenEnv framework** by Meta and Hugging Face — an open standard for training AI agents on real-world tasks. The detection model was trained using reinforcement learning, where an AI agent was repeatedly challenged to correctly identify AI-generated images, learning from its mistakes across thousands of examples.

**The goal is simple: to give everyone access to the truth about what they see.**

---

*Built with OpenEnv · Meta × PyTorch Hackathon · Scaler School of Technology*
