"""
inference.py — Baseline Agent for ImageForensicsEnv
====================================================
Required file for hackathon submission. Must be placed in the root directory.

This baseline agent uses an LLM (via OpenAI-compatible client) to analyze
forensic signals and make image detection decisions.

The agent:
  1. Connects to the running environment
  2. Reads signal features from the observation
  3. Prompts the LLM to reason over the signals
  4. Submits a verdict and logs the reward

Environment variables required:
  API_BASE_URL  — LLM API endpoint (OpenAI-compatible)
  MODEL_NAME    — Model identifier
  HF_TOKEN      — Hugging Face API token
  ENV_BASE_URL  — (optional) URL of running env, defaults to localhost:8000

Run:
  python inference.py
"""

import os
import json
import time
import logging
from openai import OpenAI
from client import ImageForensicsEnv
from models import ForensicsAction

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
API_BASE_URL = os.environ.get("API_BASE_URL", "https://api.openai.com/v1")
MODEL_NAME   = os.environ.get("MODEL_NAME", "gpt-4o-mini")
HF_TOKEN     = os.environ.get("HF_TOKEN", "")
ENV_BASE_URL = os.environ.get("ENV_BASE_URL", "http://localhost:8000")

NUM_EPISODES = 3
STEPS_PER_EPISODE = 5

# ── LLM Client ────────────────────────────────────────────────────────────────
llm = OpenAI(
    api_key=HF_TOKEN or "dummy",
    base_url=API_BASE_URL,
)


def build_prompt(obs) -> str:
    """Build a prompt for the LLM from the current observation."""
    signals_text = "\n".join(
        f"  • {s.name}: anomaly_score={s.score:.3f} — {s.description}"
        for s in obs.signals
    )
    return f"""You are an expert forensic image analyst specializing in detecting AI-generated images.

You are analyzing image ID: {obs.image_id}
Task difficulty: {obs.task_id}

FORENSIC SIGNAL ANALYSIS:
{signals_text}

Based on these forensic signals, determine whether this image is:
  - AI_GENERATED: Created by an AI model (Midjourney, DALL-E, Stable Diffusion, etc.)
  - AUTHENTIC: A real photograph taken by a camera
  - UNCERTAIN: Signals are ambiguous and you cannot determine with confidence

Signals with anomaly_score > 0.5 suggest AI generation.
Signals with anomaly_score < 0.4 suggest authentic photography.

Respond with ONLY a JSON object in this exact format (no markdown, no extra text):
{{
  "verdict": "AI_GENERATED" | "AUTHENTIC" | "UNCERTAIN",
  "confidence": <float 0.0-1.0>,
  "reasoning": "<one sentence explaining your decision>"
}}"""


def parse_llm_response(content: str) -> dict:
    """Parse LLM JSON response, with fallback."""
    try:
        clean = content.strip().replace("```json", "").replace("```", "").strip()
        return json.loads(clean)
    except json.JSONDecodeError:
        logger.warning(f"Could not parse LLM response: {content[:200]}")
        return {"verdict": "UNCERTAIN", "confidence": 0.5, "reasoning": "Parse error"}


def run_episode(env: ImageForensicsEnv, episode_num: int) -> dict:
    """Run one full episode and return stats."""
    logger.info(f"\n{'='*60}")
    logger.info(f"Episode {episode_num + 1} / {NUM_EPISODES}")
    logger.info(f"{'='*60}")

    obs = env.reset()
    logger.info(f"Task: {obs.task_id} | Image: {obs.image_id}")

    episode_reward = 0.0
    episode_correct = 0
    episode_steps = 0

    while not obs.done:
        # Build prompt and call LLM
        prompt = build_prompt(obs)
        try:
            response = llm.chat.completions.create(
                model=MODEL_NAME,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=200,
                temperature=0.1,
            )
            content = response.choices[0].message.content
            parsed = parse_llm_response(content)
        except Exception as e:
            logger.warning(f"LLM call failed: {e}. Using fallback.")
            parsed = {"verdict": "UNCERTAIN", "confidence": 0.5, "reasoning": "LLM error"}

        action = ForensicsAction(
            verdict=parsed["verdict"],
            confidence=float(parsed.get("confidence", 0.5)),
            reasoning=parsed.get("reasoning", ""),
            task_id=obs.task_id,
        )

        obs = env.step(action)
        episode_reward += obs.reward
        episode_steps += 1

        if obs.success:
            episode_correct += 1

        logger.info(
            f"  Step {obs.step_count} | verdict={action.verdict} "
            f"| conf={action.confidence:.2f} | reward={obs.reward:.2f} "
            f"| ground_truth={obs.ground_truth} | ✅ {obs.success}"
        )
        logger.info(f"  Feedback: {obs.feedback}")

        if obs.done:
            break

    accuracy = episode_correct / max(episode_steps, 1)
    logger.info(f"\n  Episode {episode_num + 1} Summary:")
    logger.info(f"  Total reward : {episode_reward:.3f}")
    logger.info(f"  Accuracy     : {accuracy:.1%}")
    logger.info(f"  Steps        : {episode_steps}")

    return {
        "episode": episode_num + 1,
        "total_reward": round(episode_reward, 3),
        "accuracy": round(accuracy, 3),
        "steps": episode_steps,
    }


def main():
    logger.info("🔬 ImageForensicsEnv — Baseline Agent")
    logger.info(f"   Model      : {MODEL_NAME}")
    logger.info(f"   API URL    : {API_BASE_URL}")
    logger.info(f"   Env URL    : {ENV_BASE_URL}")
    logger.info(f"   Episodes   : {NUM_EPISODES}")

    results = []

    with ImageForensicsEnv(base_url=ENV_BASE_URL) as env:
        # Verify env health
        try:
            health = env.health()
            logger.info(f"   Env status : {health['status']}")
        except Exception as e:
            logger.error(f"Cannot connect to environment at {ENV_BASE_URL}: {e}")
            logger.error("Make sure the server is running: uvicorn server.app:app --port 8000")
            raise SystemExit(1)

        for episode_num in range(NUM_EPISODES):
            stats = run_episode(env, episode_num)
            results.append(stats)
            time.sleep(0.5)

    # ── Final Report ──────────────────────────────────────────────────────────
    total_rewards = [r["total_reward"] for r in results]
    avg_reward = sum(total_rewards) / len(total_rewards)
    avg_accuracy = sum(r["accuracy"] for r in results) / len(results)

    logger.info(f"\n{'='*60}")
    logger.info("FINAL RESULTS")
    logger.info(f"{'='*60}")
    for r in results:
        logger.info(
            f"  Episode {r['episode']}: reward={r['total_reward']:.3f}, "
            f"accuracy={r['accuracy']:.1%}, steps={r['steps']}"
        )
    logger.info(f"\n  Average reward   : {avg_reward:.3f}")
    logger.info(f"  Average accuracy : {avg_accuracy:.1%}")
    logger.info(f"{'='*60}")

    # Write scores to file for automated grader
    with open("scores.json", "w") as f:
        json.dump({
            "episodes": results,
            "avg_reward": round(avg_reward, 3),
            "avg_accuracy": round(avg_accuracy, 3),
            "model": MODEL_NAME,
        }, f, indent=2)
    logger.info("Scores saved to scores.json")


if __name__ == "__main__":
    main()
