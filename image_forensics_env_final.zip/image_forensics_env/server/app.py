"""
FastAPI server for ImageForensicsEnv.
Exposes /reset, /step, /state endpoints per the OpenEnv HTTP spec.
"""

import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from models import ForensicsAction, ForensicsObservation
from server.environment import ImageForensicsEnvironment

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global environment instance (single-session for HF Spaces demo)
# For production multi-agent training, use HTTPEnvServer with session isolation
env = ImageForensicsEnvironment()


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🔬 ImageForensicsEnv server starting...")
    yield
    logger.info("🔬 ImageForensicsEnv server shutting down.")


app = FastAPI(
    title="ImageForensicsEnv",
    description=(
        "OpenEnv environment for training RL agents to detect AI-generated images. "
        "Implements the OpenEnv spec: /reset, /step, /state endpoints."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Health ────────────────────────────────────────────────────────────────────

@app.get("/")
async def root():
    return {
        "name": "ImageForensicsEnv",
        "version": "1.0.0",
        "status": "running",
        "description": "OpenEnv environment for AI-generated image detection",
        "endpoints": ["/reset", "/step", "/state", "/tasks", "/health"],
    }


@app.get("/health")
async def health():
    return {"status": "ok", "env": "ImageForensicsEnv"}


# ── OpenEnv Core Endpoints ────────────────────────────────────────────────────

@app.post("/reset", response_model=ForensicsObservation)
async def reset():
    """
    Reset the environment and start a new episode.
    Returns initial observation with image signals (no ground truth yet).
    """
    try:
        obs = env.reset()
        logger.info(f"Episode reset. New episode_id={env.state.episode_id}")
        return obs
    except Exception as e:
        logger.error(f"Reset failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/step", response_model=ForensicsObservation)
async def step(action: ForensicsAction):
    """
    Submit agent verdict and receive reward + ground truth.
    """
    try:
        obs = env.step(action)
        logger.info(
            f"Step {obs.step_count} | verdict={action.verdict} | "
            f"reward={obs.reward} | success={obs.success}"
        )
        return obs
    except RuntimeError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Step failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/state")
async def state():
    """
    Return current episode state metadata.
    """
    s = env.state
    return {
        "episode_id": s.episode_id,
        "step_count": s.step_count,
    }


# ── Task Discovery ────────────────────────────────────────────────────────────

@app.get("/tasks")
async def list_tasks():
    """List all available tasks with difficulty and reward info."""
    return {
        "tasks": [
            {
                "id": "easy_detection",
                "name": "Easy — Obvious AI Images",
                "difficulty": "easy",
                "reward_range": [0.0, 1.0],
                "description": "Detect clearly AI-generated images with obvious artifacts.",
            },
            {
                "id": "medium_detection",
                "name": "Medium — Subtle AI Composites",
                "difficulty": "medium",
                "reward_range": [0.0, 1.1],
                "description": "Detect AI images that mimic photographic quality.",
            },
            {
                "id": "hard_detection",
                "name": "Hard — Adversarial AI Images",
                "difficulty": "hard",
                "reward_range": [0.0, 1.2],
                "description": "Detect post-processed AI images designed to evade detection.",
            },
        ]
    }
