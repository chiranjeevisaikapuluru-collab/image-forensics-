"""
ImageForensicsEnvironment — Core OpenEnv Environment
=====================================================
A real-world RL environment where an agent learns to detect AI-generated
images by analyzing forensic signal features.

Implements the full OpenEnv spec:
  - reset()  → loads a new image sample, returns feature signals
  - step()   → receives agent verdict, computes reward, reveals ground truth
  - state    → returns episode metadata (episode_id, step_count)

Reward Design
-------------
  +1.0  Correct verdict with confidence >= 0.7
  +0.7  Correct verdict with confidence < 0.7
  +0.3  UNCERTAIN on a genuinely ambiguous sample
   0.0  Wrong verdict
  -0.1  Wrong verdict with high confidence (overconfident & wrong)

Partial credit encourages calibrated uncertainty over blind guessing.
"""

import os
import io
import uuid
import base64
import random
import logging
from typing import Optional
from uuid import uuid4

import httpx
from PIL import Image, ImageFilter, ImageEnhance
import numpy as np

# Try to import openenv base; fall back to a minimal stub for local dev
try:
    from openenv.core.env_server.interfaces import Environment
    from openenv.core.env_server.types import State
    OPENENV_AVAILABLE = True
except ImportError:
    OPENENV_AVAILABLE = False

    class State:
        def __init__(self, episode_id: str, step_count: int):
            self.episode_id = episode_id
            self.step_count = step_count

    class Environment:
        """Minimal stub when openenv package is not installed."""
        pass

from models import ForensicsAction, ForensicsObservation, SignalFeature

logger = logging.getLogger(__name__)

# ── Sample image datasets ─────────────────────────────────────────────────────
# In production these would be loaded from a curated HF dataset.
# Here we use publicly available test images + synthetic signal generation.

SAMPLE_REGISTRY = {
    "easy_detection": [
        {
            "image_id": "easy_001",
            "label": "AI_GENERATED",
            "source": "synthetic",
            "hint": "perfect_symmetry,dreamlike_bg,smooth_skin",
        },
        {
            "image_id": "easy_002",
            "label": "AUTHENTIC",
            "source": "real_photo",
            "hint": "grain,natural_noise,imperfect_lighting",
        },
        {
            "image_id": "easy_003",
            "label": "AI_GENERATED",
            "source": "synthetic",
            "hint": "blurry_hands,merged_fingers,halo_artifacts",
        },
        {
            "image_id": "easy_004",
            "label": "AUTHENTIC",
            "source": "real_photo",
            "hint": "jpeg_compression,natural_depth_of_field",
        },
    ],
    "medium_detection": [
        {
            "image_id": "med_001",
            "label": "AI_GENERATED",
            "source": "synthetic",
            "hint": "subtle_texture,inconsistent_reflections",
        },
        {
            "image_id": "med_002",
            "label": "AUTHENTIC",
            "source": "real_photo",
            "hint": "natural_blur,real_sensor_noise",
        },
        {
            "image_id": "med_003",
            "label": "AI_GENERATED",
            "source": "synthetic",
            "hint": "frequency_anomaly,oversmoothed_bg",
        },
        {
            "image_id": "med_004",
            "label": "AUTHENTIC",
            "source": "real_photo",
            "hint": "chromatic_aberration,lens_distortion",
        },
    ],
    "hard_detection": [
        {
            "image_id": "hard_001",
            "label": "AI_GENERATED",
            "source": "synthetic",
            "hint": "post_processed,noise_injected",
        },
        {
            "image_id": "hard_002",
            "label": "AUTHENTIC",
            "source": "real_photo",
            "hint": "edited_real_photo,partial_ai_inpainting",
        },
        {
            "image_id": "hard_003",
            "label": "AI_GENERATED",
            "source": "synthetic",
            "hint": "adversarial_perturbation,near_natural_noise",
        },
        {
            "image_id": "hard_004",
            "label": "AUTHENTIC",
            "source": "real_photo",
            "hint": "high_quality_camera,minimal_processing",
        },
    ],
}


def _generate_synthetic_image(label: str, difficulty: str) -> str:
    """
    Generate a synthetic placeholder image and return as base64 JPEG.
    In production, replace this with real dataset loading from HF Hub.
    """
    width, height = 256, 256
    arr = np.random.randint(0, 256, (height, width, 3), dtype=np.uint8)

    if label == "AI_GENERATED":
        # AI images tend to be smoother — apply blur
        img = Image.fromarray(arr).filter(ImageFilter.GaussianBlur(radius=2))
        img = ImageEnhance.Color(img).enhance(1.4)
    else:
        # Real photos have more noise — keep raw noise
        img = Image.fromarray(arr)

    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=85)
    return base64.b64encode(buf.getvalue()).decode()


def _extract_signals(label: str, difficulty: str, hints: str) -> list:
    """
    Extract forensic signal features from the image.
    In production, run real CV models (e.g. FFT analysis, ELA, CNNs).
    Here we simulate realistic signal scores based on ground truth + difficulty.
    """
    hint_set = set(hints.split(","))
    rng = random.Random(label + difficulty)

    def _noise(base: float, spread: float = 0.08) -> float:
        return round(min(1.0, max(0.0, base + rng.uniform(-spread, spread))), 3)

    is_ai = label == "AI_GENERATED"
    hard = difficulty == "hard_detection"
    med = difficulty == "medium_detection"

    # Scores represent "anomaly level" — higher = more suspicious of AI
    if is_ai:
        noise_score = _noise(0.3 if hard else 0.6)
        edge_score  = _noise(0.4 if hard else 0.7)
        texture_score = _noise(0.35 if hard else 0.65)
        lighting_score = _noise(0.4 if hard else 0.72)
        freq_score = _noise(0.45 if hard else 0.68)
        symmetry_score = _noise(0.5 if hard else 0.75)
    else:
        noise_score = _noise(0.75 if hard else 0.2)
        edge_score  = _noise(0.7 if hard else 0.18)
        texture_score = _noise(0.72 if hard else 0.15)
        lighting_score = _noise(0.68 if hard else 0.2)
        freq_score = _noise(0.65 if hard else 0.12)
        symmetry_score = _noise(0.6 if hard else 0.1)

    signals = [
        SignalFeature(
            name="Noise Pattern",
            score=noise_score,
            description=(
                "Natural sensor noise detected — consistent with real camera" if noise_score < 0.4
                else "Noise pattern appears synthetic or injected post-generation"
            ),
        ),
        SignalFeature(
            name="Edge Coherence",
            score=edge_score,
            description=(
                "Edge transitions are natural with organic blur gradients" if edge_score < 0.45
                else "Unnatural sharpness or halo artifacts detected at edges"
            ),
        ),
        SignalFeature(
            name="Texture Realism",
            score=texture_score,
            description=(
                "Surface textures show natural micro-detail variation" if texture_score < 0.4
                else "Textures appear overly smooth or repetitively patterned"
            ),
        ),
        SignalFeature(
            name="Lighting Consistency",
            score=lighting_score,
            description=(
                "Shadow direction and specular highlights are physically consistent" if lighting_score < 0.45
                else "Lighting inconsistencies detected across image regions"
            ),
        ),
        SignalFeature(
            name="Frequency Domain",
            score=freq_score,
            description=(
                "Frequency spectrum matches real camera sensor characteristics" if freq_score < 0.45
                else "Anomalous frequency peaks consistent with GAN/diffusion upsampling"
            ),
        ),
        SignalFeature(
            name="Structural Symmetry",
            score=symmetry_score,
            description=(
                "Facial/structural features show natural asymmetry" if symmetry_score < 0.5
                else "Near-perfect symmetry detected — uncommon in natural photography"
            ),
        ),
    ]
    return signals


def _compute_reward(
    verdict: str,
    confidence: float,
    ground_truth: str,
    task_id: str,
) -> tuple[float, bool, str]:
    """
    Compute reward, success flag, and feedback string.

    Returns (reward, success, feedback)
    """
    difficulty_bonus = {
        "easy_detection": 0.0,
        "medium_detection": 0.1,
        "hard_detection": 0.2,
    }.get(task_id, 0.0)

    if verdict == "UNCERTAIN":
        # Partial credit for honest uncertainty
        reward = 0.3 + difficulty_bonus
        success = False
        feedback = (
            f"You chose UNCERTAIN. Ground truth was {ground_truth}. "
            "Partial credit awarded for calibrated uncertainty."
        )
        return reward, success, feedback

    correct = verdict == ground_truth

    if correct:
        if confidence >= 0.7:
            reward = 1.0 + difficulty_bonus
            feedback = f"✅ Correct! {ground_truth} detected with high confidence."
        else:
            reward = 0.7 + difficulty_bonus
            feedback = f"✅ Correct! {ground_truth} detected but with low confidence."
        success = True
    else:
        if confidence >= 0.7:
            # Overconfident and wrong — penalise
            reward = -0.1
            feedback = (
                f"❌ Wrong. You said {verdict} with high confidence, "
                f"but this was {ground_truth}. Overconfidence penalty applied."
            )
        else:
            reward = 0.0
            feedback = f"❌ Wrong. You said {verdict}, but this was {ground_truth}."
        success = False

    return round(reward, 3), success, feedback


# ── Main Environment Class ────────────────────────────────────────────────────

class ImageForensicsEnvironment(Environment):
    """
    OpenEnv environment for AI-generated image detection.

    The agent receives forensic signal features and a base64 image,
    then submits a verdict (AI_GENERATED | AUTHENTIC | UNCERTAIN).
    """

    concurrency_safe = True  # Supports parallel instances

    def __init__(self):
        self._state = State(episode_id=str(uuid4()), step_count=0)
        self._current_sample: Optional[dict] = None
        self._current_task_id: str = "easy_detection"
        self._total_reward: float = 0.0
        self._episode_length: int = 5  # Steps per episode

    # ── OpenEnv Interface ─────────────────────────────────────────────────────

    def reset(self) -> ForensicsObservation:
        """Start a new episode. Returns initial observation with image + signals."""
        self._state = State(episode_id=str(uuid4()), step_count=0)
        self._total_reward = 0.0
        self._current_task_id = self._pick_task()
        self._current_sample = self._load_sample(self._current_task_id)

        signals = _extract_signals(
            label=self._current_sample["label"],
            difficulty=self._current_task_id,
            hints=self._current_sample.get("hint", ""),
        )

        image_b64 = _generate_synthetic_image(
            label=self._current_sample["label"],
            difficulty=self._current_task_id,
        )

        return ForensicsObservation(
            image_id=self._current_sample["image_id"],
            task_id=self._current_task_id,
            signals=signals,
            image_b64=image_b64,
            ground_truth=None,  # Hidden until step()
            reward=0.0,
            done=False,
            success=None,
            feedback="New episode started. Analyze the image signals and submit your verdict.",
            step_count=0,
            metadata={"episode_id": self._state.episode_id},
        )

    def step(self, action: ForensicsAction) -> ForensicsObservation:
        """
        Process agent's verdict.
        Returns observation with reward, ground truth, and feedback.
        """
        if self._current_sample is None:
            raise RuntimeError("Call reset() before step().")

        self._state.step_count += 1
        ground_truth = self._current_sample["label"]

        reward, success, feedback = _compute_reward(
            verdict=action.verdict,
            confidence=action.confidence,
            ground_truth=ground_truth,
            task_id=action.task_id,
        )

        self._total_reward += reward
        done = self._state.step_count >= self._episode_length

        # Load next sample if not done
        if not done:
            self._current_task_id = self._pick_task()
            self._current_sample = self._load_sample(self._current_task_id)
            next_signals = _extract_signals(
                label=self._current_sample["label"],
                difficulty=self._current_task_id,
                hints=self._current_sample.get("hint", ""),
            )
            next_image_b64 = _generate_synthetic_image(
                label=self._current_sample["label"],
                difficulty=self._current_task_id,
            )
            next_image_id = self._current_sample["image_id"]
            next_task_id = self._current_task_id
        else:
            next_signals = []
            next_image_b64 = None
            next_image_id = "episode_complete"
            next_task_id = self._current_task_id
            feedback += f" | Episode complete. Total reward: {self._total_reward:.2f}"

        return ForensicsObservation(
            image_id=next_image_id,
            task_id=next_task_id,
            signals=next_signals,
            image_b64=next_image_b64,
            ground_truth=ground_truth,  # Revealed after action
            reward=reward,
            done=done,
            success=success,
            feedback=feedback,
            step_count=self._state.step_count,
            metadata={
                "episode_id": self._state.episode_id,
                "total_reward": self._total_reward,
                "action_taken": action.verdict,
                "agent_confidence": action.confidence,
            },
        )

    @property
    def state(self) -> State:
        """Return current episode state."""
        return self._state

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _pick_task(self) -> str:
        """Randomly pick a task weighted by difficulty."""
        return random.choices(
            ["easy_detection", "medium_detection", "hard_detection"],
            weights=[0.4, 0.35, 0.25],
        )[0]

    def _load_sample(self, task_id: str) -> dict:
        """Load a random sample for the given task."""
        samples = SAMPLE_REGISTRY.get(task_id, SAMPLE_REGISTRY["easy_detection"])
        return random.choice(samples)
