"""
Typed data models for ImageForensicsEnv.
Defines the Action and Observation contracts for the OpenEnv spec.
"""

from pydantic import BaseModel, Field
from typing import Optional, Literal, List, Dict, Any


# ── Action ────────────────────────────────────────────────────────────────────

class ForensicsAction(BaseModel):
    """
    Action submitted by the agent after observing image features.

    verdict : The agent's classification decision.
    confidence : Agent's confidence score 0.0–1.0.
    reasoning  : Optional chain-of-thought explanation (used for grading bonuses).
    task_id    : Which task the agent is responding to.
    """
    verdict: Literal["AI_GENERATED", "AUTHENTIC", "UNCERTAIN"]
    confidence: float = Field(ge=0.0, le=1.0, description="Agent confidence 0.0–1.0")
    reasoning: Optional[str] = Field(default=None, description="Optional CoT reasoning")
    task_id: str = Field(description="Task ID: easy_detection | medium_detection | hard_detection")


# ── Observation ───────────────────────────────────────────────────────────────

class SignalFeature(BaseModel):
    """A single forensic signal feature extracted from the image."""
    name: str
    score: float = Field(ge=0.0, le=1.0, description="Signal anomaly score 0=natural, 1=synthetic")
    description: str


class ForensicsObservation(BaseModel):
    """
    Observation returned to the agent after reset() or step().

    image_id        : Unique identifier for the current image sample.
    task_id         : Active task difficulty level.
    signals         : List of forensic feature signals for the agent to reason over.
    image_b64       : Base64-encoded image (JPEG). Multimodal agents can use this directly.
    ground_truth    : Only revealed after step() — None during reset().
    reward          : Reward received for the last action (0.0 on reset).
    done            : Whether the current episode is complete.
    success         : Whether the last action was correct.
    feedback        : Human-readable feedback string.
    step_count      : Number of steps taken in this episode.
    """
    image_id: str
    task_id: str
    signals: List[SignalFeature]
    image_b64: Optional[str] = Field(default=None, description="Base64 JPEG for multimodal agents")
    ground_truth: Optional[Literal["AI_GENERATED", "AUTHENTIC"]] = None
    reward: float = 0.0
    done: bool = False
    success: Optional[bool] = None
    feedback: str = ""
    step_count: int = 0
    metadata: Dict[str, Any] = Field(default_factory=dict)
