"""
ImageForensicsEnv Client
========================
Typed Python client for connecting to a running ImageForensicsEnv server.
Follows the OpenEnv client interface pattern.

Usage:
    # Connect to HF Spaces deployment
    from client import ImageForensicsEnv
    from models import ForensicsAction

    with ImageForensicsEnv(base_url="https://your-space.hf.space") as env:
        obs = env.reset()
        result = env.step(ForensicsAction(
            verdict="AI_GENERATED",
            confidence=0.85,
            task_id=obs.task_id
        ))
        print(result.reward, result.feedback)
"""

import httpx
from models import ForensicsAction, ForensicsObservation


class ImageForensicsEnv:
    """
    Synchronous client for the ImageForensicsEnv OpenEnv server.
    """

    def __init__(self, base_url: str = "http://localhost:8000", timeout: float = 30.0):
        self.base_url = base_url.rstrip("/")
        self._client = httpx.Client(timeout=timeout)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def close(self):
        self._client.close()

    def reset(self) -> ForensicsObservation:
        """Reset the environment and return the initial observation."""
        resp = self._client.post(f"{self.base_url}/reset")
        resp.raise_for_status()
        return ForensicsObservation(**resp.json())

    def step(self, action: ForensicsAction) -> ForensicsObservation:
        """Submit a verdict action and receive the next observation."""
        resp = self._client.post(
            f"{self.base_url}/step",
            json=action.model_dump(),
        )
        resp.raise_for_status()
        return ForensicsObservation(**resp.json())

    def state(self) -> dict:
        """Return current episode state metadata."""
        resp = self._client.get(f"{self.base_url}/state")
        resp.raise_for_status()
        return resp.json()

    def tasks(self) -> dict:
        """List all available tasks."""
        resp = self._client.get(f"{self.base_url}/tasks")
        resp.raise_for_status()
        return resp.json()

    def health(self) -> dict:
        resp = self._client.get(f"{self.base_url}/health")
        resp.raise_for_status()
        return resp.json()
