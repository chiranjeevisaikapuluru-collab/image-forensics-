"""
graders.py — Automated Task Graders for ImageForensicsEnv
==========================================================
Runs each task and verifies agent scores fall in 0.0–1.0 range.
Used by the hackathon automated evaluation pipeline.
"""

import os
import json
import logging
from client import ImageForensicsEnv
from models import ForensicsAction

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

ENV_BASE_URL = os.environ.get("ENV_BASE_URL", "http://localhost:8000")

TASK_IDS = ["easy_detection", "medium_detection", "hard_detection"]
GRADER_EPISODES = 2


def grade_task(env: ImageForensicsEnv, task_id: str) -> dict:
    """
    Grade a single task by running a random baseline agent.
    Returns score in 0.0–1.0 range.
    """
    logger.info(f"  Grading task: {task_id}")
    total_reward = 0.0
    steps = 0

    for _ in range(GRADER_EPISODES):
        obs = env.reset()

        while not obs.done:
            # Random baseline — no LLM needed for grading
            import random
            action = ForensicsAction(
                verdict=random.choice(["AI_GENERATED", "AUTHENTIC", "UNCERTAIN"]),
                confidence=random.uniform(0.3, 0.9),
                task_id=obs.task_id,
                reasoning="Random baseline grader",
            )
            obs = env.step(action)
            # Clamp reward to [0, 1] for grader score
            total_reward += max(0.0, min(1.0, obs.reward))
            steps += 1

            if obs.done:
                break

    avg_score = total_reward / max(steps, 1)
    avg_score = round(min(1.0, max(0.0, avg_score)), 4)

    logger.info(f"  Task {task_id}: score={avg_score:.4f} ({steps} steps)")
    return {
        "task_id": task_id,
        "score": avg_score,
        "steps": steps,
        "valid": 0.0 <= avg_score <= 1.0,
    }


def run_all_graders():
    logger.info("🧪 Running all task graders...")
    results = []

    with ImageForensicsEnv(base_url=ENV_BASE_URL) as env:
        for task_id in TASK_IDS:
            result = grade_task(env, task_id)
            results.append(result)

    all_valid = all(r["valid"] for r in results)
    avg_score = sum(r["score"] for r in results) / len(results)

    logger.info("\n── Grader Results ──────────────────────────")
    for r in results:
        status = "✅" if r["valid"] else "❌"
        logger.info(f"  {status} {r['task_id']}: {r['score']:.4f}")
    logger.info(f"\n  All scores valid (0.0–1.0): {all_valid}")
    logger.info(f"  Mean score across tasks   : {avg_score:.4f}")

    with open("grader_scores.json", "w") as f:
        json.dump({
            "tasks": results,
            "all_valid": all_valid,
            "mean_score": round(avg_score, 4),
        }, f, indent=2)

    logger.info("Grader scores saved to grader_scores.json")
    return all_valid


if __name__ == "__main__":
    success = run_all_graders()
    exit(0 if success else 1)
